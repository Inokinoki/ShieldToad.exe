# ShieldToad-rs

ShieldToad launches a child process inside a constrained sandbox using a
single, unified policy. It compiles that policy to OS-native backends:

- **macOS**: Apple Sandbox (`sandbox-exec`) — the most complete mapping,
  with per-domain network rules enforced by a local egress proxy
- **Linux**: Landlock path rules + seccomp syscall allowlist (via
  `libseccomp`), plus no-new-privileges, capability dropping, and
  proxy-pinned egress (Landlock ABI 4)
- **Windows**: restricted tokens by default (privilege stripping only);
  opt-in AppContainer isolation via `--appcontainer`, optionally with a
  Job Object for resource limits

## Installation

Download a prebuilt binary from
[GitHub Releases](https://github.com/Inokinoki/ShieldToad-RS/releases):
Linux x86_64, macOS (Apple Silicon and Intel), and Windows x86_64
archives are attached to every release, each with a SHA-256 checksum.
The Linux binary dynamically links the system `libseccomp` (present on
mainstream distros).

Or install from source with cargo (Linux additionally needs the
`libseccomp` headers, e.g. `sudo apt-get install libseccomp-dev` on
Debian/Ubuntu):

```bash
cargo install --git https://github.com/Inokinoki/ShieldToad-RS
```

## Usage

```bash
# Basic usage (uses the platform default preset automatically)
shieldtoad -- /bin/echo hello

# Use a preset
shieldtoad --preset claude-code -- claude

# Default deny with specific allows
shieldtoad --default deny \
  --allow-read /tmp \
  --allow-stdio \
  -- /bin/cat /tmp/file.txt

# Load policy from file
shieldtoad --policy-file policy.json -- /usr/bin/python3 script.py

# List available presets
shieldtoad --list-presets

# Print the rendered macOS sandbox profile (proxy mode uses localhost:0
# as a placeholder for the per-spawn egress proxy port)
shieldtoad --print-profile

# Domain-granular egress control: the kernel pins all outbound TCP to a
# local proxy, which judges each CONNECT/SOCKS5 target by hostname
shieldtoad --default deny --allow-read /usr --allow-exec /usr/bin \
  --allow-domain api.anthropic.com:443 -- curl -s https://api.anthropic.com
```

Exit codes: the child's code passes through,
`2` = CLI/sandbox error, `125` = Linux enforcement failure (refused to
run), `130` = interrupted, `128+n` = terminated by forwarded signal.

## What is enforced

Everything below is implemented and exercised by real OS-level spawns in
CI (sandbox-exec on macOS, Landlock/seccomp on Linux, AppContainer and
restricted tokens on Windows):

- **Unified policy model** — file/network/system/device rules with
  realpath canonicalization, `env_allow`/`env_deny` glob filtering
  enforced on every spawn, JSON/TOML policy files (case-insensitive
  keys, `{workspace}`/`{home}`/`$VAR`/`~` expansion), and six built-in
  presets embedded in the binary.
- **macOS** — Apple Sandbox profiles with per-path exec rules
  (`process-exec` + `file-map-executable`), DNS/mDNSResponder allows,
  domain-widening warnings, and per-domain network enforcement via a
  local egress proxy (HTTP CONNECT, absolute-form HTTP, SOCKS5 with
  socks5h semantics, upstream chaining incl. `https://` via rustls,
  NO_PROXY).
- **Linux** — Landlock path rules (kernel 5.13+), seccomp syscall
  allowlists via libseccomp, `no_new_privs`, capability dropping, and
  Landlock ABI 4 (kernel 6.7+) outbound-TCP pinning so the egress proxy
  is the only way out; kernel-host rules (`*:PORT`, localhost, IP
  literals) are judged port-scoped by the proxy; per-path denies fail
  closed at compile time.
- **Windows** — deny-default policies compile to an AppContainer
  (profile `shieldtoad-default`) with Job Object limits;
  `--no-appcontainer` opts into the legacy restricted token (warns,
  enforces no filesystem/network rules).
- **CLI** — preset → policy file → `--default` → flags merge order,
  exit codes (2/125/130/128+n), SIGINT/SIGTERM/SIGHUP forwarding.

`https://` upstream trust uses the bundled webpki Mozilla roots; add
private CA anchors via `DomainProxy::with_upstream_tls_roots`. The
`upstream-https` cargo feature (enabled by default) carries the rustls
dependency.

The policy file grammar is documented in
[`POLICY_GRAMMAR.md`](POLICY_GRAMMAR.md).

## Known limitations

- On Windows, `--no-appcontainer` runs the legacy restricted-token path,
  which strips privileges but does **not** enforce filesystem or network
  rules (a warning is printed). Deny-default policies default to an
  AppContainer instead.
- Linux Landlock network restrictions require kernel 6.7+ (ABI 4); on
  older kernels, proxy-pinned policies refuse to start (fail closed).
  `--no-proxy` opts out by widening domain rules to any-host-on-port.
- UDP allow rules cannot be enforced on Linux (the proxy is TCP-only);
  a compile-time warning says which rules are affected. DNS in Linux
  proxy mode relies on `/etc/hosts` or a systemd-resolved unix socket
  reachable through file rules.

## API example

```rust
use shieldtoad::{Policy, run_sandboxed};

let mut policy = Policy::default_deny();
policy
    .allow_fs_read(vec!["/System", "/usr"], true)
    .allow_fs_write(vec!["/tmp"], true)
    .allow_stdio();

run_sandboxed(vec!["/bin/echo", "hello"], &policy, None)?;
```

## Development

```bash
cargo test                 # unit + integration tests (real sandbox-exec on macOS)
# Cross-checks from a non-native host: the default `upstream-https`
# feature pulls rustls/ring, whose C code needs a target C compiler;
# without a cross toolchain, check the rest of the crate instead:
cargo check --target x86_64-unknown-linux-gnu --no-default-features
cargo check --target x86_64-pc-windows-msvc --no-default-features
```

On a native host (or CI with the platform toolchain) the default
feature set builds everywhere, including `https://` upstream support.
The repo ships a three-OS GitHub Actions matrix (fmt, clippy with
`-D warnings`, tests with and without default features) — see
`.github/workflows/ci.yml`; per-release notes live in `CHANGELOG.md`.

## License

Apache License 2.0
